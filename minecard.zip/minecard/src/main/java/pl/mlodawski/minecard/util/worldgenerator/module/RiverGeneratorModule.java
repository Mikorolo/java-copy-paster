package pl.mlodawski.minecard.util.worldgenerator.module;

import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.GameWorld;
import pl.mlodawski.minecard.model.world.TileType;
import pl.mlodawski.minecard.util.worldgenerator.PerlinNoiseGenerator;
import pl.mlodawski.minecard.util.worldgenerator.TerrainModule;

import java.util.Random;

/**
 * The type River generator module.
 */
public class RiverGeneratorModule implements TerrainModule {
    @Override
    public void generateTerrain(GameWorld world, Random random) {
        PerlinNoiseGenerator perlinNoiseGenerator = new PerlinNoiseGenerator(random.nextLong());

        int riversCreated = 0;
        int maxRivers = 2;

        for (int x = 0; x < world.getWidth(); x++) {
            for (int y = 0; y < world.getHeight(); y++) {
                double noise = perlinNoiseGenerator.noise((x / 50.0), (y / 50.0));
                if (noise > 0.3 && noise < 0.7 && riversCreated < maxRivers) {
                    GameTile tile = world.getGameTiles()[x][y][0];
                    if (tile.getTileType() != TileType.ROAD && tile.getGameObject() == null) {
                        tile.setTileType(TileType.WATER);
                        riversCreated++;
                    }
                }
            }
        }
    }
}