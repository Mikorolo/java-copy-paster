package pl.mlodawski.minecard.model.world;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The type Game object.
 */
@Data
@AllArgsConstructor
@JsonSerialize
public class GameObject {
    private Integer id;
    private ObjectType objectType;

    /**
     * Instantiates a new Game object.
     */
    public GameObject() {
    }
}