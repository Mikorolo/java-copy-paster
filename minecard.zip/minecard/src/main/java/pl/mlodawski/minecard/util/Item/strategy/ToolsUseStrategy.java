package pl.mlodawski.minecard.util.Item.strategy;

import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.Item.UseStrategy;

/**
 * The type Tools use strategy.
 */
public class ToolsUseStrategy implements UseStrategy {

    @Override
    public void use(PlayerData player) {
        player.getStats().setStrength(player.getStats().getStrength() + 1);
        player.getStats().setDefense(player.getStats().getDefense() + 1);
        player.getStats().setAgility(player.getStats().getAgility() + 1);
    }

    @Override
    public void revert(PlayerData player) {
        player.getStats().setStrength(player.getStats().getStrength() - 1);
        player.getStats().setDefense(player.getStats().getDefense() - 1);
        player.getStats().setAgility(player.getStats().getAgility() - 1);
    }


}
