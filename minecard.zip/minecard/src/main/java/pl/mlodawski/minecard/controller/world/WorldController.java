package pl.mlodawski.minecard.controller.world;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.GameWorld;
import pl.mlodawski.minecard.service.world.GenerateWorldService;
import pl.mlodawski.minecard.service.world.WorldService;
import pl.mlodawski.minecard.util.worldgenerator.GameWorldSerializer;

import java.io.File;
import java.io.IOException;

/**
 * The type World controller.
 */
@Tag(name = "World", description = "The world API")
@RestController
public class WorldController {

    @Autowired
    private GameWorldSerializer gameWorldSerializer;

    @Autowired
    private GenerateWorldService generateWorldService;

    @Autowired
    private WorldService worldService;

    /**
     * Load world response entity.
     *
     * @return the response entity
     */
    @Operation(summary = "Load game world",
            description = "This method loads an existing game world from 'gameWorld.json' or generates a new one if the file doesn't exist.",
            responses = {
                    @ApiResponse(responseCode = "202", description = "Game world loaded successfully"),
                    @ApiResponse(responseCode = "201", description = "New game world generated"),
                    @ApiResponse(responseCode = "400", description = "Error occurred while loading the game world")
            })
    @PostMapping("/api/world")
    public ResponseEntity<String> loadWorld() {
        try {
            File file = new File("gameWorld.json");
            if (file.exists()) {
                GameWorld world = gameWorldSerializer.loadGameWorld();
                worldService.setWorld(world);
                return new ResponseEntity<>("World loaded", HttpStatus.ACCEPTED);
            } else {
                generateWorldService.generateWorld(256, 256);
                return new ResponseEntity<>("World generated", HttpStatus.CREATED);
            }
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error occurred while loading the world: " + e.getMessage());
        }
    }

    /**
     * Return world response entity.
     *
     * @param startX the start x
     * @param startY the start y
     * @param size   the size
     * @return the response entity
     */

    @Operation(summary = "Return game world",
            description = "This method returns a subset of the game world based on the provided parameters. It returns an error if the world or the tiles do not exist.",
            responses = {
                    @ApiResponse(responseCode = "200", description = "Successful operation",
                            content = @Content(mediaType = "application/json",
                                    schema = @Schema(implementation = GameWorld.class))),
                    @ApiResponse(responseCode = "400", description = "Bad request if the world or the tiles do not exist")
            })
    @GetMapping("/api/world")
    public ResponseEntity<GameWorld> returnWorld(@Parameter(description = "Start point in the x-axis of the world", required = false, example = "0") @RequestParam(defaultValue = "0") int startX,
                                                 @Parameter(description = "Start point in the y-axis of the world", required = false, example = "0") @RequestParam(defaultValue = "0") int startY,
                                                 @Parameter(description = "Size of the world", required = false, example = "16") @RequestParam(defaultValue = "16") int size) {
        GameWorld world = worldService.getWorld();
        if (world == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        GameTile[][][] gameTiles = world.getGameTiles();
        if (gameTiles == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        int endX = Math.min(startX + size, gameTiles[0].length - 1);
        int endY = Math.min(startY + size, gameTiles.length - 1);
        int subsetSizeX = endX - startX + 1;
        int subsetSizeY = endY - startY + 1;
        GameTile[][][] subsetGameTiles = worldService.getSubsetGameTiles(gameTiles, startX, startY, subsetSizeX, subsetSizeY);
        if (subsetGameTiles == null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
        GameWorld subsetGameWorld = new GameWorld(subsetGameTiles);
        return ResponseEntity.ok(subsetGameWorld);
    }
}