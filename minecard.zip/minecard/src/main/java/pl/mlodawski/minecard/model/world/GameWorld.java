package pl.mlodawski.minecard.model.world;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

/**
 * The type Game world.
 */
@Data

@JsonSerialize
@Schema(description = "Details about the world")
public class GameWorld {

    /**
     * The Width.
     */
    @Schema(description = "The width of the world")
    int width=256;
    /**
     * The Height.
     */
    @Schema(description = "The height of the world")
    int height=256;

    @Schema(description = "The game tiles of the world")
    private GameTile[][][] gameTiles;

    /**
     * Get game tiles game tile [ ] [ ] [ ].
     *
     * @return the game tile [ ] [ ] [ ]
     */
    public GameTile[][][] getGameTiles() {
        return gameTiles;
    }

    /**
     * Sets game tiles.
     *
     * @param gameTiles the game tiles
     */
    public void setGameTiles(GameTile[][][] gameTiles) {
        this.gameTiles = gameTiles;
    }

    /**
     * Instantiates a new Game world.
     */
    public GameWorld() {
    }

    /**
     * Instantiates a new Game world.
     *
     * @param width  the width
     * @param height the height
     */
    public GameWorld(int width, int height) {
        this.width = width;
        this.height = height;
    }

    /**
     * Instantiates a new Game world.
     *
     * @param gameTiles the game tiles
     */
    public GameWorld(GameTile[][][] gameTiles) {
        this.gameTiles = gameTiles;
    }
}