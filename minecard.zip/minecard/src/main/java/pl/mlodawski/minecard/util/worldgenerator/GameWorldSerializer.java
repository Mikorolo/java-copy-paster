package pl.mlodawski.minecard.util.worldgenerator;

import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import pl.mlodawski.minecard.model.world.GameWorld;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * The type Game world serializer.
 */
@Component
public class GameWorldSerializer {

    @Autowired
    private  ObjectMapper objectMapper;


    /**
     * Save game world.
     *
     * @param gameWorld the game world
     * @throws IOException the io exception
     */
    public void saveGameWorld(GameWorld gameWorld) throws IOException {
        Path path = Paths.get(System.getProperty("user.dir"), "gameWorld.json");
        objectMapper.writeValue(new File(path.toUri()), gameWorld);
    }

    /**
     * Load game world.
     *
     * @return the game world
     * @throws IOException the io exception
     */
    public GameWorld loadGameWorld() throws IOException {
        Path path = Paths.get(System.getProperty("user.dir"), "gameWorld.json");
        return objectMapper.readValue(new File(path.toUri()), GameWorld.class);
    }
}
