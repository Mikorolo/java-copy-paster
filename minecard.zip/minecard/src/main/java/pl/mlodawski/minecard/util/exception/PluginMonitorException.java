package pl.mlodawski.minecard.util.exception;

/**
 * Custom exception to handle plugin monitoring errors.
 */
public class PluginMonitorException extends RuntimeException {
    /**
     * Instantiates a new Plugin monitor exception.
     *
     * @param message the message
     * @param cause   the cause
     */
    public PluginMonitorException(String message, Throwable cause) {
        super(message, cause);
    }
}