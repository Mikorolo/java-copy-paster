package pl.mlodawski.minecard.config;


import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

/**
 * The type Open api config.
 */
@Configuration
public class OpenAPIConfig {

    /**
     * Example Open api model.
     *
     * @return the open api
     */
    @Bean
    public OpenAPI myOpenAPI() {

        Contact contact = new Contact();
        contact.setName("MM");
        contact.setEmail("m.mlodawski@simplemethod.io");
        contact.setUrl("https://simplemethod.io");
        License mitLicense = new License().name("MIT License").url("https://opensource.org/license/mit/");

        Server devServer = new Server();
        devServer.setUrl("http://localhost:8080/");
        devServer.setDescription("URL to the application in test mode");

        Server prodServer = new Server();
        prodServer.setUrl("https://localhost:8080/");
        prodServer.setDescription("URL to the application in production mode");

        Info info = new Info()
                .title("Minecard 2077 API")
                .version("0.1")
                .description("Example API").termsOfService("https://weaii-moodle.tu.kielce.pl/")
                .contact(contact)
                .license(mitLicense);

        return new OpenAPI().info(info).servers(List.of(devServer, prodServer));
    }
}
