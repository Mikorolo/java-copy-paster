package pl.mlodawski.minecard.util.mongo;

import jakarta.annotation.Resource;
import org.springframework.stereotype.Component;
import pl.mlodawski.minecard.model.security.MongoConfigModel;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;


/**
 * The type Mongo load config.
 */
@Component
public class MongoLoadConfig {


    @Resource
    private final Properties properties = new Properties();


    /**
     * Mongo load config mongo config model.
     *
     * @return the mongo config model
     */
    public MongoConfigModel mongoLoadConfig() {
        final Path path = Paths.get(System.getProperty("user.dir"), "MongoDB-Config.properties");
        try (
                InputStream inputStream = Files.newInputStream(path)) {
            properties.load(inputStream);
        } catch (IOException e) {
            System.err.println("Error loading config file: " + e.getMessage());
            return null;
        }

        MongoConfigModel config = new MongoConfigModel();
        config.setLogin(properties.getProperty("login"));
        config.setPassword(properties.getProperty("password"));
        config.setDatabase(properties.getProperty("database"));
        config.setUrl(properties.getProperty("url"));

        return config;
    }

}
