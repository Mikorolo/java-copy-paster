package pl.mlodawski.minecard.util.worldgenerator;

import pl.mlodawski.minecard.model.world.GameWorld;

import java.util.Random;

/**
 * The interface Structure module.
 */
public interface StructureModule {
    /**
     * Generate structure.
     *
     * @param world  the world
     * @param random the random
     */
    void generateStructure(GameWorld world, Random random);
}
