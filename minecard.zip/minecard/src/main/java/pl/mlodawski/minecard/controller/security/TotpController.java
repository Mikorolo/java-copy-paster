package pl.mlodawski.minecard.controller.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import pl.mlodawski.minecard.model.user.User;
import pl.mlodawski.minecard.repository.UserRepository;
import pl.mlodawski.minecard.service.security.TotpService;


import java.security.Principal;

/**
 * The type Totp controller.
 */
@RestController
public class TotpController {


    @Autowired
    private TotpService totpService;
    @Autowired
    private UserRepository userRepository;


    /**
     * Enable 2 fa response entity.
     *
     * @param principal the principal
     * @return the response entity
     */
    @PatchMapping("/login/2fa/enable")
    public ResponseEntity<?> enable2FA(Principal principal) {
        User user = userRepository.findByUsername(principal.getName());
        String secret = totpService.generateSecret();
        user.setSecret2FA(secret);
        user.setUsing2FA(true);
        userRepository.save(user);
        String qrUrl = totpService.generateQRUrl(user);
        return ResponseEntity.ok("{\"qrUrl\": \"" + qrUrl + "\"}");
    }

    /**
     * Verify 2 fa response entity.
     *
     * @param totp      the totp
     * @param principal the principal
     * @return the response entity
     */
    @GetMapping("/login/2fa/verify")
    public ResponseEntity<?> verify2FA(@RequestParam int totp, Principal principal) {
        User user = userRepository.findByUsername(principal.getName());
        if (totpService.verifyCode(user.getSecret2FA(), totp)) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }
}
