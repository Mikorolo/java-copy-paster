package pl.mlodawski.minecard.util.player.event;

import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.player.EventResult;
import pl.mlodawski.minecard.util.player.GameEvent;

/**
 * The type Health event.
 */
public class HealthEvent implements GameEvent {
    private final int amount;

    /**
     * Instantiates a new Health event.
     *
     * @param amount the amount
     */
    public HealthEvent(int amount) {
        this.amount = amount;
    }

    @Override
    public EventResult execute(PlayerData playerData) {
        playerData.setHealth(playerData.getHealth() + amount);
        return new EventResult("Health Increased", "Your health has been increased by " + amount);
    }
}
