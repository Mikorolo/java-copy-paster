package pl.mlodawski.minecard;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import pl.mlodawski.minecard.model.world.GameObject;
import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.ObjectType;
import pl.mlodawski.minecard.model.world.TileType;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * The type Structure writer application.
 */
public class StructureWriterApplication {

    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args) {
        GameTile[][][] structures = {
                {
                        {new GameTile(0, 0, 0, TileType.ROAD, null), new GameTile(1, 0, 0, TileType.ROAD, null), new GameTile(2, 0, 0, TileType.ROAD, null)},
                        {new GameTile(0, 1, 0, TileType.ROAD, null), new GameTile(1, 1, 0, TileType.ROAD, new GameObject(1, ObjectType.UNKNOWN)), new GameTile(2, 1, 0, TileType.ROAD, null)},
                        {new GameTile(0, 2, 0, TileType.ROAD, null), new GameTile(1, 2, 0, TileType.ROAD, null), new GameTile(2, 2, 0, TileType.ROAD, null)}
                },
                {
                        {new GameTile(0, 0, 0, TileType.ROAD, null), new GameTile(1, 0, 0, TileType.ROAD, new GameObject(2, ObjectType.UNKNOWN)), new GameTile(2, 0, 0, TileType.ROAD, null)},
                        {new GameTile(0, 1, 0, TileType.ROAD, null), new GameTile(1, 1, 0, TileType.ROAD, null), new GameTile(2, 1, 0, TileType.ROAD, null)},
                        {new GameTile(0, 2, 0, TileType.ROAD, null), new GameTile(1, 2, 0, TileType.ROAD, new GameObject(3, ObjectType.UNKNOWN)), new GameTile(2, 2, 0, TileType.ROAD, null)}
                }
        };

        String json = convertStructuresToJson(structures);
        String appDirectoryPath = getAppDirectoryPath();
        if (appDirectoryPath != null) {
            saveJsonToFile(json);
        } else {
            System.err.println("Unable to determine the application directory.");
        }
    }

    private static String convertStructuresToJson(GameTile[][][] structures) {
        try {
            return objectMapper.writeValueAsString(structures);
        } catch (JsonProcessingException e) {
            System.err.println("Error converting structures to JSON: " + e.getMessage());
        }
        return null;
    }

    private static String getAppDirectoryPath() {
        try {
            File appDirectory = new File(".");
            return appDirectory.getCanonicalPath();
        } catch (IOException e) {
            System.err.println("Error getting application directory path: " + e.getMessage());
        }
        return null;
    }

    private static void saveJsonToFile(String json) {
        Path path = Paths.get(System.getProperty("user.dir"), "structures.json");
        try (FileWriter fileWriter = new FileWriter(path.toFile())) {
            fileWriter.write(json);
        } catch (IOException e) {
            System.err.println("Error saving JSON to file: " + e.getMessage());
        }
    }
}

