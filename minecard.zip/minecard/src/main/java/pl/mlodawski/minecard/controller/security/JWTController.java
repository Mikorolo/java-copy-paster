package pl.mlodawski.minecard.controller.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pl.mlodawski.minecard.service.security.JwtService;


import java.util.List;

/**
 * The type Jwt controller.
 */
@RestController
@RequestMapping("/api/jwt")
public class JWTController {

    /**
     * The Jwt token provider service.
     */
    @Autowired
    JwtService jwtTokenProviderService;

    @PostMapping("/token/{username}/{role}")
    private ResponseEntity<String> getToken(@PathVariable String username, @PathVariable String role) {
        return ResponseEntity.ok(jwtTokenProviderService.createToken(username, List.of(role)));
    }

    @GetMapping("/token/check")
    private ResponseEntity<String> checkToken() {
        return ResponseEntity.ok("Token is correct");
    }
}
