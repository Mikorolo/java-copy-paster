package pl.mlodawski.minecard.model.player;

import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import pl.mlodawski.minecard.model.item.Item;

import java.util.ArrayList;
import java.util.List;

/**
 * The type Player data.
 */
@Data
@AllArgsConstructor
@Schema(description = "Details about the player")
public class PlayerData {

    @Schema(description = "The name of the player")
    private String playerName;

    @Schema(description = "The display name of the player")
    private String playerDisplayName;

    @Schema(description = "The unique UUID of the player")
    private String playerUUID;

    @Schema(description = "The health of the player")
    private double health;

    @Schema(description = "The food level of the player")
    private int foodLevel;

    @ArraySchema(arraySchema = @Schema(description = "The location of the player"),
            schema = @Schema(description = "A coordinate of the player", example = "123"))
    private int[] location;

    @Schema(description = "The amount of money the player has")
    private int money;

    @ArraySchema(arraySchema = @Schema(description = "The inventory of the player"),
            schema = @Schema(implementation = Item.class))
    private List<Item> inventory;

    @Schema(description = "The stats of the player", implementation = Stats.class)
    private Stats stats;

    /**
     * Instantiates a new Player data.
     *
     * @param playerName        the player name
     * @param playerDisplayName the player display name
     * @param playerUUID        the player uuid
     * @param health            the health
     * @param foodLevel         the food level
     * @param location          the location
     */
    public PlayerData(String playerName, String playerDisplayName, String playerUUID, double health, int foodLevel, int[] location) {
        this.money = 0;
        this.inventory = new ArrayList<>();
        this.playerName = playerName;
        this.playerDisplayName = playerDisplayName;
        this.playerUUID = playerUUID;
        this.health = health;
        this.foodLevel = foodLevel;
        this.location = location;
        this.inventory = new ArrayList<>();
    }


    /**
     * Instantiates a new Player data.
     *
     * @param playerName        the player name
     * @param playerDisplayName the player display name
     * @param playerUUID        the player uuid
     * @param health            the health
     * @param foodLevel         the food level
     * @param location          the location
     * @param stats             the stats
     */
    public PlayerData(String playerName, String playerDisplayName, String playerUUID, double health, int foodLevel, int[] location, Stats stats) {
        this.money = 0;
        this.inventory = new ArrayList<>();
        this.playerName = playerName;
        this.playerDisplayName = playerDisplayName;
        this.playerUUID = playerUUID;
        this.health = health;
        this.foodLevel = foodLevel;
        this.location = location;
        this.stats = stats;
    }

    /**
     * Add item to inventory.
     *
     * @param newItem the new item
     */
    public void addItemToInventory(Item newItem) {
        System.out.println("Adding item " + newItem.getId() + " to the inventory...");
        for (Item item : inventory) {
            if (newItem.getId() != null && newItem.getId().equals(item.getId())) {
                item.setQuantity(item.getQuantity() + 1);
                System.out.println("Item " + newItem.getId() + " already exists in the inventory. Quantity increased by 1.");
                return;
            }
        }
        System.out.println(inventory);
        inventory.add(newItem);
        System.out.println("Item " + newItem.getId() + " has been added to the inventory.");
    }

    /**
     * Remove item from inventory boolean.
     *
     * @param itemId the item id
     * @return the boolean
     */
    public boolean removeItemFromInventory(String itemId) {
        for (Item item : inventory) {
            if (item.getId() != null && item.getId().equals(itemId)) {
                if (item.getQuantity() > 1) {
                    item.setQuantity(item.getQuantity() - 1);
                    System.out.println("Quantity of item " + itemId + " decreased by 1.");
                } else {
                    inventory.remove(item);
                    System.out.println("Item " + itemId + " has been removed from the inventory.");
                }
                return true;
            }
        }
        return false;
    }


    /**
     * Equip item.
     *
     * @param itemId the item id
     */
    public void equipItem(String itemId) {
        for (Item item : inventory) {
            if (item.getId().equals(itemId) && item.isCanBeEquipped()) {
                for (Item otherItem : inventory) {
                    if (otherItem.isCurrentlyEquipped()) {
                        otherItem.setCurrentlyEquipped(false);
                        break;
                    }
                }
                item.setCurrentlyEquipped(true);
                item.use(this);
                System.out.println("Item " + itemId + " has been equipped.");
                break;
            }
        }
    }

    /**
     * Unequip item.
     *
     * @param itemId the item id
     */
    public void unequipItem(String itemId) {
        for (Item item : inventory) {
            if (item.getId().equals(itemId) && item.isCurrentlyEquipped()) {
                item.setCurrentlyEquipped(false);
                item.revert(this);
                System.out.println("Item " + itemId + " has been unequipped.");
                break;
            }
        }
    }

    /**
     * Use item.
     *
     * @param itemId the item id
     */
    public void useItem(String itemId) {
        for (Item item : inventory) {
            if (item.getId() != null && item.getId().equals(itemId)) {
                int quantity = item.getQuantity();
                if (quantity > 0) {
                    item.use(this);
                    quantity--;
                    item.setQuantity(quantity);
                    System.out.println("Item " + itemId + " has been used.");

                    if (quantity == 0) {
                        inventory.remove(item);
                        System.out.println("Item " + itemId + " has been removed from the inventory.");
                    }

                } else {
                    System.out.println("Item is out of stock!");
                }
                break;
            }
        }
    }

    /**
     * Instantiates a new Player data.
     */
    public PlayerData() {
        this.inventory = new ArrayList<>();
    }
}