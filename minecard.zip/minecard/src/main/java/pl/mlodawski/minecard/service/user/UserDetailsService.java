package pl.mlodawski.minecard.service.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import pl.mlodawski.minecard.model.user.User;
import pl.mlodawski.minecard.repository.UserRepository;

import java.util.Set;


/**
 * The type User details service.
 */
@Service
public class UserDetailsService implements org.springframework.security.core.userdetails.UserDetailsService {

    @Autowired
    private UserRepository userRepository;


    private final BCryptPasswordEncoder passwordBcryptEncoder = new BCryptPasswordEncoder();

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("The user with the given login does not exist:" + username);
        }

        return org.springframework.security.core.userdetails.User.builder()
                .username(user.getUsername())
                .password(user.getPassword())
                .disabled(!user.isEnabled())
                .roles(user.getRoles().toArray(new String[0]))
                .build();
    }

    /**
     * Add user.
     *
     * @param username the username
     * @param password the password
     * @param enabled  the enabled
     * @param roles    the roles
     */
    public void addUser(String username, String password, boolean enabled, Set<String> roles) {
        String encodedPassword = passwordBcryptEncoder.encode(password);
        User user = new User(username, encodedPassword, enabled, roles);
        userRepository.save(user);
    }

}
