package pl.mlodawski.minecard.controller.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.mlodawski.minecard.repository.UserRepository;
import pl.mlodawski.minecard.service.user.UserDetailsService;


import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * The type User init controller.
 */
@RestController
@RequestMapping("/api/public")
public class UserInitController {

    @Autowired
    private UserDetailsService userService;


    /**
     * Initialize users response entity.
     *
     * @return the response entity
     */
    @PostMapping("/app/init")
    public ResponseEntity<String> initializeUsers() {
        Set<String> userRoles = new HashSet<>(List.of("USER"));
        Set<String> adminRoles = new HashSet<>(List.of("ADMIN"));
        Set<String> modRoles = new HashSet<>(List.of("MODERATOR"));
        Set<String> playerRoles = new HashSet<>(List.of("PLAYER"));

        userService.addUser("user", "password", true, userRoles);
        userService.addUser("admin", "password", true, adminRoles);
        userService.addUser("mod", "password", true, modRoles);
        userService.addUser("player", "password", true, playerRoles);

        return ResponseEntity.ok("Predefined users were added successfully");
    }
    @Autowired
    private UserRepository userRepository;

    public void siur() {
        userRepository.deleteAll();
    }

}