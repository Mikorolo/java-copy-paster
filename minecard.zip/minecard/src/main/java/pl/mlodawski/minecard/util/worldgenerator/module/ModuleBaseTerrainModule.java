package pl.mlodawski.minecard.util.worldgenerator.module;

import pl.mlodawski.minecard.model.world.*;
import pl.mlodawski.minecard.util.worldgenerator.PerlinNoiseGenerator;
import pl.mlodawski.minecard.util.worldgenerator.TerrainModule;

import java.util.Random;

/**
 * The type Module base terrain module.
 */
public class ModuleBaseTerrainModule implements TerrainModule {

    @Override
    public void generateTerrain(GameWorld world, Random random) {

        PerlinNoiseGenerator perlin = new PerlinNoiseGenerator(random.nextLong());
        GameTile[][][] tiles = world.getGameTiles();
        for (int x = 0; x < world.getWidth(); x++) {
            for (int y = 0; y < world.getHeight(); y++) {
                tiles[x][y][0].setTileType(TileType.GRASS);

                // Overall chance for an object to be placed
                double objectChance = 0.15;
                if (random.nextDouble() < objectChance) {
                    double noiseValue = perlin.noise(x / 10.0, y / 10.0);
                    if (noiseValue < 0.25) {
                        tiles[x][y][0].setGameObject(new GameObject(ObjectType.WOOD.ordinal(), ObjectType.WOOD));
                    } else if (noiseValue < 0.5) {
                        tiles[x][y][0].setGameObject(new GameObject(ObjectType.FLOWER.ordinal(), ObjectType.FLOWER));
                    } else if (noiseValue < 0.75) {
                        tiles[x][y][0].setGameObject(new GameObject(ObjectType.TREE.ordinal(), ObjectType.TREE));
                    } else {
                        tiles[x][y][0].setGameObject(new GameObject(ObjectType.ROCK.ordinal(), ObjectType.ROCK));
                    }
                }
            }
        }
    }
}