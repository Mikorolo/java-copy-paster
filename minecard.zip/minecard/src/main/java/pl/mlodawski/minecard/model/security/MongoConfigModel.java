package pl.mlodawski.minecard.model.security;

import lombok.AllArgsConstructor;
import lombok.Data;


/**
 * The type Mongo config model.
 */
@Data
@AllArgsConstructor
public class MongoConfigModel
{
    private String login;
    private String password;
    private String database;
    private String url;

    /**
     * Instantiates a new Mongo config model.
     */
    public MongoConfigModel() {
    }

    /**
     * Generate connection string.
     *
     * @return the string
     */
    public String generateConnectionString() {
        return "mongodb://" + this.login + ":" + this.password + "@" + this.url + "/" + this.database
                + "?authMechanism=SCRAM-SHA-1&authSource=" + this.database;
    }
}