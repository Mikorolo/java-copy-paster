package pl.mlodawski.minecard.model.world;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The type Game tile.
 */
@Data
@AllArgsConstructor
@JsonSerialize
public class GameTile {
    private int x;
    private int y;
    private int z;
    private TileType tileType;
    private GameObject gameObject;

    /**
     * Instantiates a new Game tile.
     */
    public GameTile() {
    }
}