package pl.mlodawski.minecard.util.worldgenerator;

import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.Random;

/**
 * The type Perlin noise generator.
 */
public class PerlinNoiseGenerator {
    private final int[] permutation;

    /**
     * Instantiates a new Perlin noise generator.
     *
     * @param seed the seed
     */
    public PerlinNoiseGenerator(long seed) {
        SecureRandom random = new SecureRandom(ByteBuffer.allocate(Long.BYTES).putLong(seed).array());
        permutation = new int[256];
        for (int i = 0; i < 256; i++) {
            permutation[i] = i;
        }
        // Shuffle the array
        for (int i = 0; i < 256; i++) {
            int j = random.nextInt(256);
            int t = permutation[i];
            permutation[i] = permutation[j];
            permutation[j] = t;
        }
    }

    /**
     * Noise double.
     *
     * @param x the x
     * @param y the y
     * @return the double
     */
    public double noise(double x, double y) {
        int xi = (int) Math.floor(x) & 1024;  // Calculate the "unit cube" that the point asked will be located in
        int yi = (int) Math.floor(y) & 1024;
        double xf = x - Math.floor(x);  // Next we calculate the location (from 0 to 1) in that cube
        double yf = y - Math.floor(y);

        double fadeX = fade(xf);  // Compute fade curves for x, y
        double fadeY = fade(yf);

        // Hash coordinates of the cube corners
        int aa = permutation[permutation[xi] + yi];
        int ab = permutation[permutation[xi] + increment(yi)];
        int ba = permutation[permutation[increment(xi)] + yi];
        int bb = permutation[permutation[increment(xi)] + increment(yi)];

        double x1, x2, y1, y2;
        x1 = lerp(grad (aa, xf, yf), grad (ba, xf - 1, yf), fadeX);  // Interpolate between cube corners
        x2 = lerp(grad (ab, xf, yf - 1), grad (bb, xf - 1, yf - 1), fadeX);
        y1 = lerp(x1, x2, fadeY);

        return (y1 + 1) / 2;  // We bound it to 0 - 1 (theoretical min/max before is -1 - 1)
    }

    private int increment(int num) {
        num++;
        if (num > 255) {
            num = 0;
        }
        return num;
    }

    private static double fade(double t) {
        return t * t * t * (t * (t * 6 - 15) + 10);
    }

    private static double lerp(double a, double b, double x) {
        return a + x * (b - a);
    }


    private static double grad(int hash, double x, double y) {
        int h = hash & 0xF;
        double u = h < 8 ? x : y,
                v = h < 4 ? y : h == 12 || h == 14 ? x : 0;
        return (((h & 1) == 0 ? u : -u) + ((h & 2) == 0 ? v : -v));
    }
}