package pl.mlodawski.minecard.service.player;



import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.player.EventResult;
import pl.mlodawski.minecard.util.player.GameEvent;

/**
 * The type Player service.
 */
@Service
public class PlayerService {

    @Autowired
    private ObjectMapper objectMapper;
    private PlayerData playerData;

    /**
     * Gets player data.
     *
     * @return the player data
     */
    public PlayerData getPlayerData() {
        return playerData;
    }

    /**
     * Sets player data.
     *
     * @param playerData the player data
     */
    public void setPlayerData(PlayerData playerData) {
        this.playerData = playerData;
    }

    /**
     * Move player.
     *
     * @param newX the new x
     * @param newY the new y
     */
    public void movePlayer(int newX, int newY) {
        int[] currentLocation = playerData.getLocation();
        int[] newLocation = {newX, newY, currentLocation[2]};
        playerData.setLocation(newLocation);
    }

    /**
     * Update player data.
     *
     * @param newX              the new x
     * @param newY              the new y
     * @param updatedPlayerData the updated player data
     */
    public void updatePlayerData(int newX, int newY, PlayerData updatedPlayerData) {
        int[] currentLocation = playerData.getLocation();
        int[] newLocation = {newX, newY, currentLocation[2]};
        playerData.setLocation(newLocation);
        playerData.setHealth(updatedPlayerData.getHealth());
        playerData.setPlayerName(updatedPlayerData.getPlayerName());
        playerData.setPlayerUUID(updatedPlayerData.getPlayerUUID());
        playerData.setFoodLevel(updatedPlayerData.getFoodLevel());
    }

    /**
     * Create player.
     *
     * @param newPlayerData the new player data
     */
    public void createPlayer(PlayerData newPlayerData) {
        this.playerData = newPlayerData;
    }

    /**
     * Handle event string.
     *
     * @param gameEvent the game event
     * @return the string
     * @throws JsonProcessingException the json processing exception
     */
    public String handleEvent(GameEvent gameEvent) throws JsonProcessingException {
        try {
            EventResult eventResult = gameEvent.execute(playerData);
            return objectMapper.writeValueAsString(eventResult);
        }
        catch (NullPointerException e)
        {
            return "No event found";
        }
    }
}