package pl.mlodawski.minecard.controller.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;
import pl.mlodawski.minecard.model.user.User;
import pl.mlodawski.minecard.model.user.UserDTO;
import pl.mlodawski.minecard.repository.UserRepository;

import java.security.Principal;

/**
 * The type User controller.
 */
@RestController
public class UserController {

    @Autowired
    private UserRepository userRepository;

    /**
     * Current user name response entity.
     *
     * @param principal the principal
     * @return the response entity
     */
    @GetMapping("/api/user")
    public ResponseEntity<UserDTO> currentUserName(Principal principal) {
        if (principal == null) {
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Principal is null");
        }
        User user = userRepository.findByUsername(principal.getName());
        if (user == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "User not found");
        }
        UserDTO userDTO = new UserDTO();
        userDTO.setId(user.getId());
        userDTO.setUsername(user.getUsername());
        userDTO.setEnabled(user.isEnabled());
        userDTO.setRoles(user.getRoles());
        userDTO.setUsing2FA(user.isUsing2FA());

        return new ResponseEntity<>(userDTO, HttpStatus.OK);
    }
}
