package pl.mlodawski.minecard.model.world;


import com.fasterxml.jackson.databind.annotation.JsonSerialize;


/**
 * The enum Object type.
 */
@JsonSerialize
public enum ObjectType {
    /**
     * Tree object type.
     */
    TREE("🌲"),
    /**
     * Cactus object type.
     */
    CACTUS("🌵"),
    /**
     * Chest object type.
     */
    CHEST("📦"),
    /**
     * Flower object type.
     */
    FLOWER("🌼"),
    /**
     * Player object type.
     */
    PLAYER("🕵️"),
    /**
     * House object type.
     */
    HOUSE("🏘"),
    /**
     * Abandoned house object type.
     */
    ABANDONED_HOUSE("🏚"),
    /**
     * Modern house object type.
     */
    MODERN_HOUSE("🏢"),
    /**
     * Modern house 2 object type.
     */
    MODERN_HOUSE_2("🏬"),
    /**
     * Hospital object type.
     */
    HOSPITAL("🏥"),
    /**
     * Factory object type.
     */
    FACTORY("🏭"),
    /**
     * Shop object type.
     */
    SHOP("🏪"),
    /**
     * Country house object type.
     */
    COUNTRY_HOUSE("🛖"),
    /**
     * Dangerous place object type.
     */
    DANGEROUS_PLACE("♨"),
    /**
     * Bank object type.
     */
    BANK("🏦"),
    /**
     * Hotel object type.
     */
    HOTEL("🏨"),
    /**
     * Wood object type.
     */
    WOOD("🪵"),
    /**
     * Rock object type.
     */
    ROCK("🪨"),
    /**
     * Unknown object type.
     */
    UNKNOWN("❓");

    private final String emoji;

    ObjectType(String emoji) {
        this.emoji = emoji;
    }

    /**
     * Gets emoji.
     *
     * @return the emoji
     */
    public String getEmoji() {
        return emoji;
    }
}