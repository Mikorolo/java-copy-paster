package pl.mlodawski.minecard.util.player;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import pl.mlodawski.minecard.model.player.PlayerData;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * The type Player serializer.
 */
@Component
public class PlayerSerializer {
    @Autowired
    private ObjectMapper objectMapper;

    /**
     * Save player data.
     *
     * @param playerData the player data
     * @throws IOException the io exception
     */
    public void savePlayerData(PlayerData playerData) throws IOException {
        final Path path = Paths.get(System.getProperty("user.dir"), "player.json");
        objectMapper.writeValue(new File(path.toUri()), playerData);
    }

    /**
     * Load player data player data.
     *
     * @return the player data
     * @throws IOException the io exception
     */
    public PlayerData loadPlayerData() throws IOException {
        final Path path = Paths.get(System.getProperty("user.dir"), "player.json");
        return objectMapper.readValue(new File(path.toUri()), PlayerData.class);
    }

    /**
     * Player data exists boolean.
     *
     * @return the boolean
     */
    public boolean playerDataExists() {
        final Path path = Paths.get(System.getProperty("user.dir"), "player.json");
        File file = path.toFile();
        return file.exists() && !file.isDirectory();
    }
}
