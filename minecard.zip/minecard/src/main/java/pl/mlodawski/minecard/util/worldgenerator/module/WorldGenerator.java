package pl.mlodawski.minecard.util.worldgenerator.module;

import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.GameWorld;
import pl.mlodawski.minecard.model.world.TileType;
import pl.mlodawski.minecard.util.worldgenerator.StructureModule;
import pl.mlodawski.minecard.util.worldgenerator.TerrainModule;


import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * The type World generator.
 */
public class WorldGenerator {
    private final GameWorld gameWorld;
    private final List<StructureModule> structureModules;
    private final List<TerrainModule> terrainModules;

    /**
     * Instantiates a new World generator.
     *
     * @param width  the width
     * @param height the height
     */
    public WorldGenerator(int width, int height) {
        this.gameWorld = new GameWorld(width, height);
        this.structureModules = new ArrayList<>();
        this.terrainModules = new ArrayList<>();
        GameTile[][][] gameTiles = new GameTile[width][height][1];
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                for (int z = 0; z < 1; z++) {
                    gameTiles[x][y][z] = new GameTile(x, y, z, TileType.GRASS, null);
                }
            }
        }
        this.gameWorld.setGameTiles(gameTiles);
    }

    /**
     * Add structure module.
     *
     * @param module the module
     */
    public void addStructureModule(StructureModule module) {
        this.structureModules.add(module);
    }

    /**
     * Add terrain module.
     *
     * @param module the module
     */
    public void addTerrainModule(TerrainModule module) {
        this.terrainModules.add(module);
    }

    /**
     * Generate game world.
     *
     * @return the game world
     */
    public GameWorld generate() {
        SecureRandom random = new SecureRandom();

        for (TerrainModule module : terrainModules) {
            module.generateTerrain(gameWorld, random);
        }
        for (StructureModule module : structureModules) {
            module.generateStructure(gameWorld, random);
        }

        return gameWorld;
    }
}