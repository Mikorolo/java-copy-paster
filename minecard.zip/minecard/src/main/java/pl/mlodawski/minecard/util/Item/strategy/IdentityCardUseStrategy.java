package pl.mlodawski.minecard.util.Item.strategy;

import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.Item.UseStrategy;

/**
 * The type Identity card use strategy.
 */
public class IdentityCardUseStrategy implements UseStrategy {
    @Override
    public void use(PlayerData player) {
    }

    @Override
    public void revert(PlayerData player) {

    }

}
