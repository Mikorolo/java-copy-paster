package pl.mlodawski.minecard.model.player;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * The type Stats.
 */
@Data
@AllArgsConstructor
@JsonSerialize
@Schema(description = "Stats of the player")
public class Stats {

    @Schema(description = "The strength of the player")
    private int strength;

    @Schema(description = "The defense of the player")
    private int defense;

    @Schema(description = "The agility of the player")
    private int agility;

    @Schema(description = "The intelligence of the player")
    private int intelligence;

    @Schema(description = "The charisma of the player")
    private int charisma;

    @Schema(description = "The luck of the player")
    private int luck;

    /**
     * Instantiates a new Stats.
     */
    public Stats() {
    }
}
