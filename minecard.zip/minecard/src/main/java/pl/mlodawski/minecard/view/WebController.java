package pl.mlodawski.minecard.view;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * The type Web controller.
 */
@Controller
public class WebController {


    /**
     * Admin dashboard string.
     *
     * @return the string
     */
    @GetMapping("/admin/dashboard")
    public String adminDashboard() {
        return "admin_dashboard";
    }

    /**
     * Mod dashboard string.
     *
     * @return the string
     */
    @GetMapping("/moderator/dashboard")
    public String modDashboard() {
        return "mod_dashboard";
    }

    /**
     * User profile string.
     *
     * @return the string
     */
    @GetMapping("/user/profile")
    public String userProfile() {
        return "user_profile";
    }

    /**
     * Public home string.
     *
     * @return the string
     */
    @GetMapping("/public/game")
    public String publicHome() {
        return "game";
    }

    /**
     * Home string.
     *
     * @return the string
     */
    @GetMapping("/")
    public String home() {
        return "home";
    }

    /**
     * Login string.
     *
     * @return the string
     */
    @GetMapping("/login")
    public String login() {
        return "login";
    }

    /**
     * Logout string.
     *
     * @return the string
     */
    @GetMapping("/logout")
    public String logout() {
        return "logout";
    }
}
