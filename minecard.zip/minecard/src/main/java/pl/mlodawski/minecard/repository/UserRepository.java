package pl.mlodawski.minecard.repository;


import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;
import pl.mlodawski.minecard.model.user.User;


/**
 * The interface User repository.
 */
@Repository
public interface UserRepository extends MongoRepository<User, String> {
    /**
     * Find by username user.
     *
     * @param username the username
     * @return the user
     */
    User findByUsername(String username);

    /**
     * Find by provider and provider id user.
     *
     * @param provider   the provider
     * @param providerId the provider id
     * @return the user
     */
    User findByProviderAndProviderId(String provider, String providerId);
}