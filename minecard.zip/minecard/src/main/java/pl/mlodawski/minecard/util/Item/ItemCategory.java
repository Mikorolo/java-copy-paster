package pl.mlodawski.minecard.util.Item;

/**
 * The enum Item category.
 */
public enum ItemCategory {
    /**
     * Food item category.
     */
    FOOD("Food"),
    /**
     * Clothing item category.
     */
    CLOTHING("Clothing"),
    /**
     * Items item category.
     */
    ITEMS("Items"),
    /**
     * Tools item category.
     */
    TOOLS("Tools"),
    /**
     * Books item category.
     */
    BOOKS("Books"),
    /**
     * Electronics item category.
     */
    ELECTRONICS("Electronics"),
    /**
     * Other item category.
     */
    OTHER("Other");

    private final String displayName;

    ItemCategory(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Gets display name.
     *
     * @return the display name
     */
    public String getDisplayName() {
        return displayName;
    }
}