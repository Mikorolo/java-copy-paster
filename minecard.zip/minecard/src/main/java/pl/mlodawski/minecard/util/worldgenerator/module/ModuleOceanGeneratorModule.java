package pl.mlodawski.minecard.util.worldgenerator.module;

import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.GameWorld;
import pl.mlodawski.minecard.model.world.ObjectType;
import pl.mlodawski.minecard.model.world.TileType;
import pl.mlodawski.minecard.util.worldgenerator.TerrainModule;

import java.util.Random;

/**
 * The type Module ocean generator module.
 */
public class ModuleOceanGeneratorModule implements TerrainModule {

    @Override
    public void generateTerrain(GameWorld world, Random random) {
        GameTile[][][] tiles = world.getGameTiles();
        int width = tiles.length;
        int height = tiles[0].length;

        // Generate ocean tiles and remove objects on water
        // Width of the ocean from the edge of the map
        int oceanWidth = 8;
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (x < oceanWidth || y < oceanWidth || x >= width - oceanWidth || y >= height - oceanWidth) {
                    tiles[x][y][0].setTileType(TileType.WATER);
                    tiles[x][y][0].setGameObject(null);
                }
            }
        }

        // Generate beach tiles with rocks
        for (int x = oceanWidth; x < width - oceanWidth; x++) {
            for (int y = oceanWidth; y < height - oceanWidth; y++) {
                if (x == oceanWidth || y == oceanWidth || x == width - oceanWidth - 1 || y == height - oceanWidth - 1) {
                    tiles[x][y][0].setTileType(TileType.BEACH);
                    if (tiles[x][y][0].getGameObject() != null && tiles[x][y][0].getGameObject().getObjectType() != ObjectType.ROCK) {
                        tiles[x][y][0].setGameObject(null);
                    }
                }
            }
        }
    }
}