package pl.mlodawski.minecard.util.player.event;

import pl.mlodawski.minecard.model.item.Item;
import pl.mlodawski.minecard.model.player.PlayerData;
import pl.mlodawski.minecard.util.player.EventResult;
import pl.mlodawski.minecard.util.player.GameEvent;
import pl.mlodawski.minecard.util.Item.*;
import pl.mlodawski.minecard.util.Item.strategy.*;

/**
 * The type Add item event.
 */
public class AddItemEvent implements GameEvent {
    private final ItemType itemType;

    /**
     * Instantiates a new Add item event.
     *
     * @param itemType the item type
     */
    public AddItemEvent(ItemType itemType) {
        this.itemType = itemType;
    }

    @Override
    public EventResult execute(PlayerData playerData) {
        Item item = createItem(itemType);
        playerData.addItemToInventory(item);
        return new EventResult("Item Added", "You received a " + itemType.getDisplayName());
    }

    private Item createItem(ItemType itemType) {
        return switch (itemType) {
            case HEADGEAR_1 ->
                    new Item("3", "Headgear 1", ItemType.HEADGEAR_1, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case HEADGEAR_2 ->
                    new Item("4", "Headgear 2", ItemType.HEADGEAR_2, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case HEADGEAR_3 ->
                    new Item("5", "Headgear 3", ItemType.HEADGEAR_3, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case HEADGEAR_4 ->
                    new Item("6", "Headgear 4", ItemType.HEADGEAR_4, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case SHOES_1 ->
                    new Item("7", "Shoes 1", ItemType.SHOES_1, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case SHOES_2 ->
                    new Item("8", "Shoes 2", ItemType.SHOES_2, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case SHOES_3 ->
                    new Item("9", "Shoes 3", ItemType.SHOES_3, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case SHOES_4 ->
                    new Item("10", "Shoes 4", ItemType.SHOES_4, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case TOP_1 ->
                    new Item("11", "Top 1", ItemType.TOP_1, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case TOP_2 ->
                    new Item("12", "Top 2", ItemType.TOP_2, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case TOP_3 ->
                    new Item("13", "Top 3", ItemType.TOP_3, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case TOP_4 ->
                    new Item("14", "Top 4", ItemType.TOP_4, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case TOP_5 ->
                    new Item("15", "Top 5", ItemType.TOP_5, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case TOP_6 ->
                    new Item("16", "Top 6", ItemType.TOP_6, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case TOP_7 ->
                    new Item("17", "Top 7", ItemType.TOP_7, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case BOTTOMS_1 ->
                    new Item("18", "Bottoms 1", ItemType.BOTTOMS_1, ItemCategory.CLOTHING, true, 1, new ClothingUseStrategy());
            case PHONE_1 ->
                    new Item("19", "Phone 1", ItemType.PHONE_1, ItemCategory.ELECTRONICS, true, 1, new ElectronicsUseStrategy());
            case PHONE_2 ->
                    new Item("20", "Phone 2", ItemType.PHONE_2, ItemCategory.ELECTRONICS, true, 1, new ElectronicsUseStrategy());
            case LAPTOP_1 ->
                    new Item("21", "Laptop 1", ItemType.LAPTOP_1, ItemCategory.ELECTRONICS, true, 1, new ElectronicsUseStrategy());
            case DISK -> new Item("22", "Disk", ItemType.DISK, ItemCategory.OTHER, false, 1, new DiskUseStrategy());
            case DVD -> new Item("23", "DVD", ItemType.DVD, ItemCategory.OTHER, false, 1, new DiskUseStrategy());
            case SCROLL ->
                    new Item("24", "Scroll", ItemType.SCROLL, ItemCategory.OTHER, false, 1, new BookUseStrategy());
            case BOOK -> new Item("25", "Book", ItemType.BOOK, ItemCategory.OTHER, false, 1, new BookUseStrategy());
            case FLOPPY_DISK ->
                    new Item("26", "Floppy Disk", ItemType.FLOPPY_DISK, ItemCategory.OTHER, false, 1, new DiskUseStrategy());
            case FLASHLIGHT ->
                    new Item("27", "Flashlight", ItemType.FLASHLIGHT, ItemCategory.TOOLS, true, 1, new ElectronicsUseStrategy());
            case CAMERA ->
                    new Item("28", "Camera", ItemType.CAMERA, ItemCategory.ELECTRONICS, true, 1, new ElectronicsUseStrategy());
            case TOMATO ->
                    new Item("29", "Tomato", ItemType.TOMATO, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case MELON -> new Item("30", "Melon", ItemType.MELON, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case WATERMELON ->
                    new Item("31", "Watermelon", ItemType.WATERMELON, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case STRAWBERRY ->
                    new Item("32", "Strawberry", ItemType.STRAWBERRY, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case MANGO -> new Item("33", "Mango", ItemType.MANGO, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case FALAFEL ->
                    new Item("34", "Falafel", ItemType.FALAFEL, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case SANDWICH ->
                    new Item("35", "Sandwich", ItemType.SANDWICH, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case ICE_CREAM ->
                    new Item("36", "Ice Cream", ItemType.ICE_CREAM, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case MEDICINE ->
                    new Item("37", "Medicine", ItemType.MEDICINE, ItemCategory.FOOD, false, 1, new FoodUseStrategy());
            case IDENTITY_CARD ->
                    new Item("38", "Identity Card", ItemType.IDENTITY_CARD, ItemCategory.OTHER, false, 1, new IdentityCardUseStrategy());
            case PICKAXE ->
                    new Item("39", "Pickaxe", ItemType.PICKAXE, ItemCategory.TOOLS, true, 1, new ToolsUseStrategy());
            case HAMMER ->
                    new Item("40", "Hammer", ItemType.HAMMER, ItemCategory.TOOLS, true, 1, new ToolsUseStrategy());
            case AXE -> new Item("41", "Axe", ItemType.AXE, ItemCategory.TOOLS, true, 1, new ToolsUseStrategy());
            default -> throw new IllegalArgumentException("Unsupported item type: " + itemType);
        };
    }
}
