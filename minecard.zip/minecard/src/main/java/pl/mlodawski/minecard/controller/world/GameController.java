package pl.mlodawski.minecard.controller.world;

import org.springframework.stereotype.Controller;
import pl.mlodawski.minecard.util.Item.ItemType;
import pl.mlodawski.minecard.util.player.event.AddItemEvent;
import pl.mlodawski.minecard.util.player.GameEvent;

import java.util.HashMap;
import java.util.Map;

/**
 * The type Game controller.
 */
@Controller
public class GameController {

    private final Map<Integer, GameEvent> eventMap;

    /**
     * Instantiates a new Game controller.
     */
    public GameController() {
        eventMap = new HashMap<>();
        eventMap.put(0, null);
        eventMap.put(1, new AddItemEvent(ItemType.AXE));
        eventMap.put(15, new AddItemEvent(ItemType.STRAWBERRY));
    }

    /**
     * Gets event by id.
     *
     * @param eventId the event id
     * @return the event by id
     */
    public GameEvent getEventById(int eventId) {
        return eventMap.get(eventId);
    }

}
