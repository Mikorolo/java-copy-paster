package pl.mlodawski.minecard.service.world;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;
import pl.mlodawski.minecard.model.world.GameTile;
import pl.mlodawski.minecard.model.world.GameWorld;

/**
 * The type World service.
 */
@Service
public class WorldService {



    private GameWorld world;

    /**
     * Gets world.
     *
     * @return the world
     */
    public GameWorld getWorld() {
        return world;
    }

    /**
     * Sets world.
     *
     * @param world the world
     */
    public void setWorld(GameWorld world) {
        this.world = world;
    }

    /**
     * Get subset game tiles game tile [ ] [ ] [ ].
     *
     * @param gameTiles the game tiles
     * @param startX    the start x
     * @param startY    the start y
     * @param sizeX     the size x
     * @param sizeY     the size y
     * @return the game tile [ ] [ ] [ ]
     */
    public GameTile[][][] getSubsetGameTiles(GameTile[][][] gameTiles, int startX, int startY, int sizeX, int sizeY) {
        if (startX < 0 || startY < 0 || startX + sizeX > gameTiles[0].length || startY + sizeY > gameTiles.length) {
            throw new IllegalArgumentException("Invalid start or size parameters");
        }

        GameTile[][][] subset = new GameTile[sizeY][sizeX][1];

        for (int i = startY; i < startY + sizeY; i++) {
            for (int j = startX; j < startX + sizeX; j++) {
                subset[i - startY][j - startX][0] = gameTiles[i][j][0];
            }
        }

        return subset;
    }

}
