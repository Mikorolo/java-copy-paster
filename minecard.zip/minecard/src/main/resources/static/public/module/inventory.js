import { getPlayerData } from './player.js';

export function equipItem(itemId, getPlayerData) {
    axios
        .put('/api/player/inventory/equip/' + itemId)
        .then(function (response) {
            renderInventory();
            return getPlayerData();
        })
        .catch(function (error) {
            console.error(error);
        });
}

export function unequipItem(itemId, getPlayerData) {
    axios
        .put('/api/player/inventory/unequip/' + itemId)
        .then(function (response) {
            renderInventory();
            return getPlayerData();
        })
        .catch(function (error) {
            console.error(error);
        });
}

export function useItem(itemId, getPlayerData) {
    axios
        .put('/api/player/inventory/use/' + itemId)
        .then(function (response) {
            renderInventory();
            return getPlayerData();
        })
        .catch(function (error) {
            console.error(error);
        });
}

export function renderInventory() {
    const inventoryModalList = $('#inventoryModalList');
    inventoryModalList.html('');

    axios
        .get('/api/player/inventory')
        .then(function (response) {
            const inventory = response.data;

            for (const item of inventory) {
                const listItem = $('<li></li>');
                const itemName = $('<span class="item-name">' + item.name + '</span>');
                const itemCategory = $('<span class="item-category">' + item.itemCategory + '</span>');
                const equipButton = $('<button class="btn btn-primary equip-btn">Załóż</button>');
                const unequipButton = $('<button class="btn btn-primary unequip-btn">Zdejmij</button>');
                const useButton = $('<button class="btn btn-primary use-btn">Zużyj</button>');

                listItem.append(itemName);
                listItem.append(itemCategory);

                equipButton.hide();
                unequipButton.hide();
                useButton.hide();

                if (item.canBeEquipped && (item.itemCategory === 'TOOLS' || item.itemCategory === 'CLOTHING')) {
                    if (item.currentlyEquipped) {
                        unequipButton.show();
                    } else {
                        equipButton.show();
                    }
                } else if (item.itemCategory === 'FOOD' || item.itemCategory === 'BOOKS') {
                    useButton.show();
                }

                listItem.append(equipButton);
                listItem.append(unequipButton);
                listItem.append(useButton);

                inventoryModalList.append(listItem);

                equipButton.on('click', function () {
                    equipItem(item.id, getPlayerData);
                });

                unequipButton.on('click', function () {
                    unequipItem(item.id, getPlayerData);
                });

                useButton.on('click', function () {
                    useItem(item.id, getPlayerData);
                });
            }
        })
        .catch(function (error) {
            console.error(error);
        });
}