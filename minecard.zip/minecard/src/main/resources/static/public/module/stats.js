export function renderStats(stats) {
    $('#strength').text(stats.strength);
    $('#defense').text(stats.defense);
    $('#agility').text(stats.agility);
    $('#intelligence').text(stats.intelligence);
    $('#charisma').text(stats.charisma);
    $('#luck').text(stats.luck);
}